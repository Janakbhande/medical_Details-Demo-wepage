<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedicalDetails</title>
    <style>
        .container1 {
            box-sizing: border-box;
            justify-content: center;
            text-align: center;
            align-items: center;
            border: 1px bisque solid;
            border-radius: 5px;
            width: 80cw;
            height: 100%;
            background-color: lightskyblue;
            position: relative;
        }

        .container2 {
            margin: 20px;
        }

        .container3 {
            padding-left: 45px;
            margin: 20px;
            display: flexbox;
            width: 100%;
        }

        .button {
            width: 45%;
            cursor: pointer;
        }

        .button:hover{
            color:blue;
        }

        .button:focus{
            background-color: aqua;
        }

        .table {
            border: 1px black solid;
            margin-top: 10px;
            width: 91%;
        }

        .theader {
            border: 1px black solid;
            font-weight: bold;
        }

        .container4 {
            margin: 30px;
            box-sizing: border-box;
            border: 1px solid black;
            display: none;
        }

        label {
            display: flexbox;
            width: 30%;
        }

        .form input[type="text"],
        .form input[type="date"],
        .form input[type="varchar"],
        .form input[type="checkbox"],
        .form input[type="file"] {
            margin: 10px;
            width: 40%;
            flex-flow: row;
        }

        .form input:focus{
            border:2px red;
            padding: 5px;
        }

        .form button[type="submit"] {
            margin: 10px;
            width: 80px;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: 1px solid black;
            border-radius: 5px;
            cursor: pointer;
        }

        .form button[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>

<body>

    <div class="container1">
        <h1>Medical Details </h1>
        <h5>to enhance medical records experience</h5>
        <div class="header container2">
            <div class="hbutton">
                <button class="button button1" type="submit" onclick="viewHistory()">History</button>
                <button class="button button2" type="submit" onclick="addNewMedicalDetails()">Add</button>
            </div>
        </div>
        <div class="container3">
            <table class="table" border="1" cellspacing="0" cellpadding="5px">
                <thead>
                    <tr>
                        <th class="theader">Id</th>
                        <th class="theader">Patient Name</th>
                        <th class="theader">Date_of_Treatment</th>
                        <th class="theader">Hospital Name</th>
                        <th class="theader">Symptoms</th>
                        <th class="theader">Medicine details</th>
                        <th class="theader">Receipt</th>
                        <th class="theader">Delete</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    if (isset($_POST['submit'])) {
                        $con = mysqli_connect("localhost", "root", "Janak@123", "medicalDetails");
                        if (!$con) {
                            die("connection to this database failed due to " . mysqli_connect_error());
                        }

                        $idno = $_POST['idno'];
                        $pname = $_POST['pname'];
                        $date = $_POST['date'];
                        $hospitalName = $_POST['hospitalname'];
                        $symptoms = $_POST['symptoms'];
                        $medicines = $_POST['medicines'];
                        $receipt = $_FILES['receipt'];
                        $filename = $receipt['name'];
                        $fileerror = $receipt['error'];
                        $filetmp = $receipt['tmp_name'];
                        $fileext = explode('.',$filename);
                        $filecheck = strtolower(end($fileext));
                        $fileextstored = array('png','jpg','jpeg','pdf');

                        if(in_array($filecheck,$fileextstored)){
                            $destinationfile = 'receipts/'.$filename;
                            move_uploaded_file($filetmp,$destinationfile);
                        }

                        $sql = "INSERT INTO `medicaldetails` (`EntryId`, `patientName`, `dateOfTreatment`, `hospitalName`, `symptoms`,`medicines`, `receipt`) VALUES ('$idno', '$pname', '$date', '$hospitalName', '$symptoms','$medicines', '$destinationfile');";
                        if ($con->query($sql) == true) {
                            // echo "Successfully inserted";
                            $insert = true;
                        } else {
                            echo "Error: .$sql <br> $con -> error";
                        }
                        $con->close();
                        
                    }
                    ?>



                    <?php
                       
                        $con = mysqli_connect("localhost", "root", "Janak@123", "medicalDetails");
                        if (!$con) {
                            die("connection to this database failed due to " . mysqli_connect_error());
                        }

                       
                        $displayQuery = " select * from medicaldetails;";
                        $querydisplay = mysqli_query($con,$displayQuery);

                        // $row = mysqli_num_rows($querydisplay);

                        while($result = mysqli_fetch_array($querydisplay)) {

                            ?>

                            <tr>
                                <td> <?php echo $result['EntryId']; ?></td>
                                <td> <?php echo $result['patientName']; ?></td>
                                <td> <?php echo $result['dateOfTreatment']; ?></td>
                                <td> <?php echo $result['hospitalName']; ?></td>
                                <td> <?php echo $result['symptoms']; ?></td>
                                <td> <?php echo $result['medicines']; ?></td>
                                <td> <a href="<?php echo $result['receipt']; ?>"><img src="images/receipt.jpg" alt="shoe receipt" width="30px" height="30px"></a></td>
                                <td>
                                    <form method="post">
                                        <input type="hidden" name="delete_id" value="<?php echo $result['EntryId']; ?>">
                                        <button type="submit" name="delete" class="delete-button"><img src="images/deletepng.png" alt="delete" height="10px" width="10px"></button>
                                    </form>
                                </td>
                            </tr>
                            <?php
                        }

                        $con->close();
                    
                    ?>



                    <?php
                        if (isset($_POST['delete'])) {
                            $delete_id = $_POST['delete_id'];
                            $con = mysqli_connect("localhost", "root", "Janak@123", "medicalDetails");
                            if (!$con) {
                                die("Connection to this database failed due to " . mysqli_connect_error());
                            }
                            $sql = "DELETE FROM `medicaldetails` WHERE EntryId = $delete_id";
                            
                            if ($con->query($sql) === TRUE) {
                                // echo '<script>alert("Record deleted successfully.");</script>';
                                // header('Location: ' . $_SERVER['PHP_SELF']);
                                // exit();
                            } else {
                                echo "Error: " . $sql . "<br>" . $con->error;
                            }
                            $con->close();
                        }
                        
                    ?>

                </tbody>

            </table>
        </div>
        <div class="container4">
            <form class="form" action="index.php" method="post" enctype="multipart/form-data">
                <br>
                <label for="pname">ID: </label>
                <input type="number" name="idno" id="idno" placeholder="Sr no">
                <br>
                <label for="pname">Enter patient Name: </label>
                <input type="text" name="pname" id="pname" placeholder="patientName">
                <br>
                <label for="date">Date of Treatment: </label>
                <input type="date" name="date" id="date">
                <br>
                <label for="hospitalname">Hospital Name: </label>
                <input type="varchar" name="hospitalname" id="hospitalname">
                <br>
                <label for="Symptoms">Symptoms: </label>
                <input type="varchar" name="symptoms" id="symptoms"
                    placeholder="Enter multiple symptoms separated by commas">
                <br>
                <label for="medicines">Medicines: </label>
                <textarea name="medicines" id="medicines" cols="30" rows="10" placeholder = "Write names of medicines with usage description."></textarea>
                <br>
                <label for="receipt">Receipt: </label>
                <input type="file" name="receipt" id="receipt">
                <br>
                <button type="submit" name="submit" id="submit">Add</button>
            </form>
        </div>
    </div>
</body>

<script>
    let history = document.querySelector(".container3");
    let add = document.querySelector(".container4");

    function viewHistory() {
        history.style.display = "block";
        add.style.display = "none";

    }

    function addNewMedicalDetails() {
        history.style.display = "none";
        add.style.display = "block";
    }

</script>

</html>
